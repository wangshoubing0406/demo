const express=require("express");
const router=express.Router();
const pool=require("../pool");

router.post('/signin',(req,res)=>{
    var $uname=req.body.uname;
    var $upwd=req.body.upwd;
    //对象解构
    //var{uname,upwd}=req.body;
    //sql语句
    var sql='SELECT * FROM wyj_user WHERE uname=? AND upwd=?';
    pool.query(sql,[$uname,$upwd],(err,result)=>{
          if(result.length>0){
              res.send({code:200,msg:"登录成功"})
          }else{
              res.send({code:404,msg:"登录失败"})
          }
        });
    });

 //以下用post请求
 /* router.post("/signin",(req,res)=>{
      //获取参数 用对象解构
      var {uname,upwd}=req.body;
      //sql语句
      var sql="SELECT * FROM wyj_user WHERE  uname=? AND upwd=?";
      //连接数据库
      pool.query(sql,[uname,upwd],(err,result)=>{
            if(err) throw err;
              console.log(err)
            //解决跨域问题
            res.writeHead(200,{
                "Content-type":"application/json;charset=utf-8",
                "Access Control-Allow-Origin":"*"   //这是为了解决跨域问题
              });
              console.log(result)
              //判断是否查询到
          if(result.length>0)
          res.write(JSON.stringify({ok:1}))
          else
          res.write(JSON.stringify({ok:0,msg:"用户名或密码错误"}))
            //发送响应
         res.send();

      });




  })*/












//导出
module.exports=router;




