const express= require("express");
const router=express.Router();
const pool=require("../pool");

//轮播
router.get('/',(req,res)=>{
    var sql=`select*from wyj_carousel`;
    pool.query(sql,[],(err,result)=>{
      if(err)
       console.log(err)
       res.send(result)
    })



})





//index/
router.get("/list",(req,res)=>{
  var sql=`SELECT * FROM wyj_index_p`;
 
  pool.query(sql,[],(err,result)=>{
    if(err)
      console.log(err);
    res.send(result);
  })
})






module.exports=router;