const express= require("express");
const router=express.Router();
const pool=require("../pool");


// //details
// router.get("/",(req,res)=>{
//    //按lid查询商品信息和规格属性列表
//    var lid=req.query.lid,obj={product:{},specs:[],pics:[]}

//     //1. 按lid查询商品信息——异步
    
//       console.log(sql)
//       pool.query(sql,[lid],(err,result)=>{
//         if(err) console.log(err);
//         obj.product=result[0];
//         console.log(result)
//         res.send(result)
//     })
//     // res.send(obj)
//   })
  // })()
// })




router.get("/",(req,res)=>{
  var lid=req.query.lid,obj={product:{},specs:[]}
 
    

    //1. 按lid查询商品信息——异步
    var sql="SELECT * FROM wyj_laptap where lid=?";
      pool.query(sql,[lid],(err,result)=>{
        if(err) console.log(err);
        obj.product=result[0];
        console.log(result[0]);
      })
    //2. 按lid查询规格列表——异步
   var sql="select lid, spec from wyj_laptap "
        sql+= "  where family_id=("
         sql+= " select family_id from wyj_laptap where lid=?)";

     pool.query(sql,[lid],(err,result)=>{
       if(err) console.log(err);
       obj.specs=result;
      //console.log(obj.specs)
      res.send(obj)
     })
});
 
  module.exports=router;

















