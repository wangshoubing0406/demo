const express = require('express');
const pool = require('../pool.js');//导入连接数据库的模块
//使用路由器
var router = express.Router();
//添加请求方法为post，url为add的路由
router.post('/add',(req,res)=>{
   //获取参数
   var obj=req.body;
  //对客户端所传递的数据进行验证
  var $uname = obj.uname;
  var $upwd = obj.upwd;
  var $cpwd=obj.cpwd;
  var $phone=obj.phone;
  //sql语句
  var sql = 'INSERT INTO wyj_user VALUES(null,?,?,?,?)';
  pool.query(sql,[$uname,$upwd,$cpwd,$phone],(err,result)=>{
     if(err) throw err;
     console.log(result)
     if(result.affectedRows>0){
       res.send({code:200,msg:"注册成功"})
     }else{
       res.send({code:404,msg:"注册失败"})
     }

    

  })
  




})












module.exports = router;
