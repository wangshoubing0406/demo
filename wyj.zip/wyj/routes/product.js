const express= require("express");
const router=express.Router();
const pool=require("../pool");

   router.get("/",(req,res)=>{
     //参数
     var  kw=req.query.kw;
     var kws=kw.split(" ");
     ///console.log(kw)
     kws.forEach((elem,i,kws)=>{
    kws[i]=` title like '%${elem}%' `;
  })
   
 
  // console.log(where)
     //sql语句
     var sql=`SELECT *FROM wyj_laptap where ${kws.join(" and ")} `;
//查全部，不分页
//console.log(sql)
     //查询
   var pno=req.query.pno;
  //sql+=` limit ${pno*9},9 `;//不再用sql的limit截取
  pool.query(sql,(err,result)=>{
    if(err) console.log(err);
       console.log(result)
    data={};//新建结果对象
    data.pno=req.query.pno;//在结果对象中添加pno属性
    //用查询结果的总数/16,上取整，获得总页数，放入结果data中
     data.pageCount=Math.ceil(result.length/16)
    // //仅截取查询结果中的pno*16还是的16条记录，放入data中
     data.product=result.slice(data.pno*16,data.pno*16+16)
    res.send(result);
   //console.log(data)
  })





   })








module.exports=router;
