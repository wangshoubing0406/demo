(()=>{
  
 function productList(pno){
    var kw=null;//给kw设置一个初始值
    if(location.search){
         kw=location.search.split("=")[1];
         console.log(kw);
         $.ajax({
             type:'GET',
             url:'http://localhost:3000/product/',
             data:{
                 kw,
                 pno
             },
             success: function(data) {
                 //console.log(data)
                 var html="";
             for(var p of data.data){
                html+=`<dl id=${p.ID}>
                <dt><a href="details.html?gid=${p.lid}"><img src="${p.thumbnail_url}" alt="${p.goods_name}"></a></dt>
                <dd class="gname"><a href="${'details.html?gid='+p.ID}">${p.goods_name}</a></dd>
                <dd class="gprice">¥${parseFloat(p.price).toFixed(2)}/${p.units}</dd>
                <dd class="gcart"><button><img src="img/header/shop_car.png">&nbsp;加入购物车</button></dd>
            </dl>`; 


             }




             }


         })


    }
    



}


productList(1)






})();






