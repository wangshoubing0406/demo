$(function(){
   //获取位置
   var $uname=$("#uname");
   var $upwd=$("#pwd");
   var $cpwd=$("#cpwd");
   var $mobile=$("#mobile");
    
   //失去焦点验证用户名
   $uname.blur(e=>{
    valiRegDB($(e.target),/^[A-Za-z]\w{5,31}$/,"http://localhost:3000/reg/add",{uname:$(e.target).val()},"用户名不能为空","用户名以字母开头，字母/数字/下划线组成的6~32位字符串","用户名已被占用");
  });

  //失去焦点验证密码
  $upwd.blur(e=>{
    valiReg($(e.target),/^\d{3,6}$/,"密码不能为空","密码为3~6位的数字");
  });

    //两次密码一致验证
  function confirmPwd(){
    if($upwd.val()!==$cpwd.val()){
      $cpwd.next().next().html("两次输入的密码不一致");
      input=false;
    }else{
      $cpwd.next().next().html("");
      input=true;
    }
  }
//重复密码验证
  $cpwd.blur(e=>{
    valiReg($(e.target),/^\d{3,6}$/,"密码不能为空","密码为3~6位的数字");
    if(!input){
      $cpwd.next().next().html("请先输入密码");
    }else{
      confirmPwd();
    }
  });

 //按钮点击事件
  $("#agr-reg").click(function(){
    if($(this).prop("checked")){
      $("[data-btn=reg]").removeClass("btn-reg");
      $("[data-btn=reg]").prop("disabled",false);
    }else{
      $("[data-btn=reg]").addClass("btn-reg");
      $("[data-btn=reg]").prop("disabled",true);
    }
  });
         //手机失去焦点
  $mobile.blur(e=>{
    valiRegDB($(e.target),/^1[34578]\d{9}$/,"http://localhost:3000/reg/add",{mobile:$(e.target).val()},"手机号不能为空","请输入合法的手机号","手机号已被占用");
  });
      //点击事件
  $("[data-btn=reg]").click(e=>{
    e.preventDefault();
     //调用函数
    valiRegDB($uname,/^[A-Za-z]\w{5,31}$/,"http://localhost:3000/reg/add",{uname:$(e.target).val()},"用户名不能为空","用户名以字母开头，字母/数字/下划线组成的6~32位字符串","用户名已被占用");
    valiReg($upwd,/^\d{3,6}$/,"密码不能为空","密码为3~6位的数字");
     //dian
    confirmPwd();

    valiRegDB($mobile,/^1[34578]\d{9}$/,"http://localhost:3000/reg/add",{mobile:$(e.target).val()},"手机号不能为空","请输入合法的手机号","手机号已被占用");

    if(input){
          $.ajax({
           url:"http://localhost:3000/reg/add",
           type:"post",
           data:"uname:$uname.val(),upwd:$upwd.val(),mobile:$mobile.val()",
           datatype:"json",
           success:function(data){
              alert("注册成功")
              if(data.code==200){
               alert("注册成功"),
               location.href="index.html";
             }else{
             alert("网络错误，请重试")
             }
            }
         })
       }
    });
});































































