var input=true;
function valiInput(txt,msg){
  if(!txt.val()){
    txt.next().next().html(msg);
    input=false;
  }else{
    txt.next().next().html("");
    input=true;
  }
}


function valiDB(txt,url,data,mgs1,msg2){
	if(!txt.val()){
		txt.next().next().html(msg1);
    input=false;
	}else{
		$.post(url,data,msg=>{
	    if(msg=='false'){
	      txt.next().next().html(msg2);
	      input=false;
	    }else{
	      txt.next().next().html("");
	      input=true;
	    }
	  });
	}
}


function valiReg(txt,reg,msg1,msg2){
	if(!txt.val()){
		txt.next().next().html(msg1);
    input=false;
	}else{
		if(reg.test(txt.val())){
			txt.next().next().html("");
	    input=true;
		}else{
			txt.next().next().html(msg2);
      input=false;
		}
	}
}



function valiRegDB(txt,reg,url,data,msg1,msg2,msg3){
	if(!txt.val()){
		txt.next().next().html(msg1);
    input=false;
	}else{
		if(reg.test(txt.val())){
			$.post(url,data,msg=>{
		    if(msg=='false'){
		      txt.next().next().html(msg3);
		      input=false;
		    }else{
		      txt.next().next().html("");
		      input=true;
		    }
		  });
		}else{
			txt.next().next().html(msg2);
      input=false;
		}
	}
}








