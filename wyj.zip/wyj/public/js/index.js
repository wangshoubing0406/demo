(async function(){  //异步请求数据
     var res=await ajax({
         url:"http://localhost:3000/index/list",
         type:"get",
         dataType:"json"
     });  
     console.log(res);
//用Vue动态绑定
   new Vue({
        el:"#main",
         data:{
            res:res
        }
        
    })




   // 查找第一个商品
  /* var p=res[0];
   //第一个商品的位置
     var parent=document.querySelector(".f-f1>.sub");
      console.log(parent);
      var {href,pname,title,pic}=p
      var html=`<a href="${href}">
      <div class="txt">
        <p class="name">${pname}</p>
<p class="advert">${title}<span>Go&gt;&gt;</span></p>
      </div>
      <img src="${pic}" class="p-img">
    </a>`;
      parent.innerHTML=html;
     
   
 //第二个商品的位置
  var parent=document.querySelector(".f-f1>.redbg");
 var p1=res[1];
   console.log(p1);
   var {href,title,pname,pic,details}=p1;
   var html=`<a href="${href}">
   <div class="txt">
     <p class="name">${pname}</p>
     <p class="advert">${title}</p>
     <p class="more">${details}&gt;&gt;</p>
   </div>
   <img src="${pic}" class="p-img">
 </a> `;
parent.innerHTML=html;


 
//获取3 的位置
 var parent=document.querySelector(".f-f1>.yellowbg");
  var p2=res[2];
  console.log(p2);
   var {href,pname,title,details,pic}=p2;
   var html=`<a href="${href}">
   <div class="txt">
     <p class="name">${pname}</p>
     <p class="advert">${title}</p>
     <p class="more">${details}&gt;&gt;</p>
   </div>
   <img src="${pic}" class="p-img">
 </a> `;
     console.log(html);
     parent.innerHTML=html;
//4
var parent=document.querySelector(".f-f1>.bluebg");
var p3=res[3];
console.log(p3);
 var {href,pname,title,details,pic}=p3;
 var html=`<a href="${href}">
 <div class="txt">
   <p class="name">${pname}</p>
   <p class="advert">${title}</p>
   <p class="more">${details}&gt;&gt;</p>
 </div>
 <img src="${pic}" class="p-img">
</a> `;
   console.log(html);
   parent.innerHTML=html;
     
   
   
   //5-9
   var parent =document.querySelector("#f>.hotlist>.subar2>a:first-child");
    console.log(parent);
    var p4=res[4];
    console.log(p4);
    var {href,pname,details,pic}=p4;
    var html=`<a href="${href}">
    <div class="txt">
      <p class="name">${pname}</p>
      <p class="more">${details}&gt;&gt;</p>
    </div>
    <img src="${pic}" class="p-img">
  </a> `;
 parent.innerHTML=html;

 var parent =document.querySelector("#f>.hotlist>.subar2>a:last-child ");
    console.log(parent);
    var p5=res[5];
    console.log(p5);    
    var {href,pname,details,pic}=p5;
    var html=`<a href="${href}">
    <div class="txt">
      <p class="name">${pname}</p>
      <p class="more">${details}&gt;&gt;</p>
    </div>
    <img src="${pic}" class="p-img">
  </a> `;
  console.log(html);
 parent.innerHTML=html;
    
   








    
})()  */
//测试：
 // http://localhost:3000/index.html



 
  var fids=$(".floor>.floor-id"); //每个楼层的顶部文字
  var $ulLift=$("#lift>ul"); //电梯按钮区域
    console.log("fids")
  var str="";
  //var scrollTop=document.body.scrollTop || window.pageYOffset || document.body.scrollTop;
  for(var fid of fids){
    str+=`<li class="lift_item">
            <a href="#" class="lift_btn">
              <span>${fid.textContent.slice(3)}</span>
            </a>
          </li>`;
  }
  $ulLift.html(str).children(":first").addClass("lift_item_on"); //显示电梯按钮，默认第一个选中
  function getOffsetTop(elem){  //获取当前元素距页面顶端的距离
    var offsetTop=elem.offsetTop; //元素对象距离父元素的距离
    while(elem.offsetParent){  //如果有父元素
      elem=elem.offsetParent;
      offsetTop+=elem.offsetTop;	
    }
    return offsetTop;
  }
  var floors=[...$(".floor")];
      //循环每个楼层
  for(var f of floors){
    f.totalTop=getOffsetTop(f);
  }
  var DIST=0,DURA=500,STEPS=100,  //100是步长
      moved=0,step=0,interval=DURA/STEPS,
      timer=null;
  function moveTo(i){ //跳转到第i个楼层
    var scrollTop=document.body.scrollTop || window.pageYOffset || document.body.scrollTop;
    if(timer!=null){
      clearInterval(timer);
      timer=null;
      moved=0;
    }
    //scrollTop出现滚动条时，表示已向上滚动过去的内容的高度，只在出现滚动条时有效，反映了内容向上滚动的距离。
    DIST=floors[i].totalTop-scrollTop; //
    console.log(DIST);
    step=DIST/STEPS;
    console.log(step);
    timer=setInterval(moveStep,interval);
  }
  function moveStep(){
    moved++;        				//scrollTo(x,y)	把内容滚动到指定的坐标
    window.scrollBy(0,step); //scrollBy(x,y)按照指定的像素值来滚动内容
    if(moved==STEPS){
      clearInterval(timer);
      timer=null;
      moved=0;
      checkOn();
    }
  }
  for(let i=0;i<$ulLift.children().length;i++){
    $ulLift.children(":eq("+i+")").click(()=>{
      moveTo(i);
    });			
  }
  window.addEventListener("scroll",()=>{
    var minTop=floors[0].totalTop-innerHeight/2;
    var scrollTop=document.body.scrollTop || window.pageYOffset || document.body.scrollTop;
    if(scrollTop>=minTop){
      $ulLift.parent().css("display","block");
    }else{
      $ulLift.parent().css("display","");
    }
    checkOn();
  });
  var FHEIGHT=parseFloat(getComputedStyle(floors[0]).height); //444
  function checkOn(){
    var scrollTop=document.body.scrollTop || window.pageYOffset || document.body.scrollTop;
    for(var i=0;i<floors.length;i++){
      if(scrollTop>=floors[i].totalTop-innerHeight/2&&scrollTop<floors[i].totalTop+FHEIGHT-innerHeight/2){
        $ulLift.children(":eq("+i+")").addClass("lift_item_on");
      }else{
        $ulLift.children(":eq("+i+")").removeClass("lift_item_on");
      }
    }
  }
})();
