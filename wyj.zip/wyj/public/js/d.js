(()=>{
    if(location.search.indexOf("lid=")!=-1){
      var lid=location.search.split("=")[1];
            //   注意 其他页面传参   
       $.ajax({
        url:"http://localhost:3000/d",
        type:"get",
        data:`lid=${lid}`,
        dataType:"json",
        success:function(result){
          console.log(result) //对象解构
          var {product,specs}=result;
           //console.log(specs)
          var {title,price}=product;
          var html= `<h1 class="title">${title} </h1>
          <!-- 价格部分-->
          <div class="price">
              <div id="pro_price"><b>商城售价：</b>
                  <span>¥${price}</span>
              </div>
              <div class="promise">
                  <b>服务承诺：</b>
                  <img src="img/d/promise.png" alt="">
                  <span>&nbsp;&nbsp;*退货补运费</span>
                  <span>&nbsp;&nbsp;*7天无忧退货</span><br>
                  <span style="padding-left:106px;">&nbsp;&nbsp;*24小时                                 快速退款</span>
                  <span>&nbsp;&nbsp;*24小时发货</span>
              </div>
          </div>`
        var parent=document.getElementsByClassName("right_detail")[0];
               //console.log(parent)
            parent.innerHTML=html+parent.innerHTML;
            // console.log(parent.innerHTML) 
              var  html="";
            for(var s of specs){
                  //console.log(s.lid,lid)
              html+=`<a href="#" class="avenge  ${s.lid==lid?'borderChange':''}" href="d.html?lid=${s.lid}"> ${s.spec}</a>`;
            }
           var p=document.getElementsByClassName("spec");
             p[0].innerHTML=html          
        }

      });
    }

var p=document.getElementById("p1");
 var btns= p.getElementsByTagName("button");
    //console.log(btns);
  for(var i=0;i<btns.length;i++  ){
      console.log(btns[i])
     btns[i].onclick=function(){
           var input=this.parentNode.children[2];
          
         //console.log(thisnerHTML).in
          var n=parseInt(input.value);
          if(this.innerHTML=="+"){
             n++;
          }else if(n>1){
             n--;
         }
         input.value=n;
     };
}
})();
   /*左右箭头*/
var $backword=$(".backward");
var $forward=$(".forward");
 //console.log($backword)
//获取父元素ul
var $ul=$("#icon_list");
 //console.log($ul);
 var moved= 0,LIWIDTH=100;

  //给右箭头绑定事件
$forward.click(function(){
    var $forward=$(this);
     //条件判断disabled 
    if(!$forward.is(".disabled")){
        moved++;
        $ul.css("marginLeft",-LIWIDTH*moved);
        //给左边按钮去掉disabled
        $backword.removeClass("disabled");
        //什么时候禁用右边按钮  3表示一行展示几个图片
        if($ul.children().length-3==moved){
            $forward.addClass("disabled")
        }
    }
});
    //给左边箭头绑定事件
$backword.click(function(){
    var $forward=$(this);
    //条件判断disabled 
    if(!$forward.is(".disabled")){
        moved--;
        $ul.css("marginLeft",-LIWIDTH*moved);
        if($ul.children().length+moved==3){
            $backword.addClass("disabled")
           }
        }
});


//小图片切换中图片
//1.获取中图片的位置
var $mImg=$("#md-img");
//获取大图片的位置
var $lImg=$("#lg-img");

 //2.绑定鼠标进入事件
             //小图片切换大图片
     $ul.on("mouseover","img",function(){
           var $img=$(this);
         var img=$img.attr("data-lg");
         // console.log($img)
          //小图片切换中图片 用attr函数获取data-md自定义扩展属性
         var md=$img.attr("data-md");
        $mImg.attr('src',md);
         $('#md-img').attr("data-lg",md);
         
     });
     //console.log(img)
// $lImg.css("backgroundImage",`url()`)
       //放大镜部分
$('#superMask').on('mouseover',function(){
   $('#lg-img').attr('display','block');
    $ul.children('img');
    var lg=$('#md-img').attr('src');
    $('#lg-img').css('background',`url('${lg}')no-repeat`);
})
/*获取小方块和放大镜*/
  var $mask=$("#mask"),$smask=$("#superMask");
  $smask.mouseenter(e=>{
      $lImg.show();
     // console.log($lImg)
  })
$smask.mouseleave(e=>{
    $lImg.hide();
})

/*放大镜*/
  $smask.mousemove(e=>{
      var MSIZE=200,SMSIZE=360, MAX=SMSIZE-MSIZE;
      var top=e.offsetY-MSIZE/2;
      var left=e.offsetX-MSIZE/2;
      $mask.css({top,left}) //更改小方块的位置样式
      $lImg.css("backgroundPosition",`${-16/7*left}px ${-16/7*top}px`)
       $mask.show();
       $lImg.show();
    /*判断*/
      if(top<0) top=0;
      else if(top>MAX) top=MAX ;
      if(left<0) left=0;
      else if(left>MAX) left=MAX ;
})
 $smask.mouseout(e=>{
     $mask.hide();
     $lImg.hide();
})

/**添加购物车 立即购买 添加收藏 */
$(function () {
    var nav = $("#tab"); //得到导航对象
    var win = $(window); //得到窗口对象
    var sc = $(document);//得到document文档对象。
    win.scroll(function () {
        if (sc.scrollTop() >= 900) {
            nav.addClass("fixed_tab");
        }else {
            nav.removeClass("fixed_tab");
        }
    });

    win.scroll(function () {
        if (sc.scrollTop() >= 170 && sc.scrollTop() < 600) {
            $("#header-top").addClass("fixed_nav");
        }else {
            $("#header-top").removeClass("fixed_nav");
        }
    });
/**选择商品不同规格 悬停效果**/
$(".spec").on('mouseenter', '.avenge',function () {
    $(this).css({"border": "1px solid #0AA1ED", "color": "#0AA1ED"}); //链式操作
}).on('mouseleave', '.avenge', function () {
    $(this).css({"border": "1px solid #666", "color": "#666"})
});
   console.log($(".spec"))
});





