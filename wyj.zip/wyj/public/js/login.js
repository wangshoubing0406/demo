/*( function(){  //异步请求数据
     $.ajax({
        url:"http://localhost:3000/login/signin",
        type:"post",
        dataType:"json",
        success:function(result){
            console.log(result)
        }
    });  
  
 //绑定事件
 var $uname=$("#uname");
 var $upwd=$("#pwd");
  $uname.onblur=function(){
      var $span=$uname.next();
      $span.html("用户名不能为空")

  }
  $upwd.onblur=function(){
     var  $span=$upwd.next();
      $span.html("密码不能为空")
  }










})();
*/



$(function(){
    var $uname=$("#uname");
    var $upwd=$("#pwd");

    $uname.blur(e=>{
      valiInput($(e.target),"用户名不能为空");
    });
    $upwd.blur(e=>{
      valiInput($(e.target),"密码不能为空");
    });
    $("[data-btn=login]").click(e=>{
      e.preventDefault();
         //调函数传参
      valiInput($uname,"用户名不能为空");
      valiInput($upwd,"密码不能为空");
      if(input){
        // $.post("http://localhost:3000/login/signin",{uname:$uname.val(),upwd:$upwd.val()},data=>{
        //   console.log(data);
        //   console.log(typeof (data));
        //   console.log(data["code"]);
        //   if(data.code==200){
        //     alert("登录成功");
        //     location.href="index.html";
        //   }else{
        //     $(e.target).prev().html("登录失败");
        //   }
        // });
           $.ajax({
             url:"http://localhost:3000/login/signin",
             type:"post",
             data:{uname:$uname.val(),upwd:$upwd.val()},
             datatype:"json",
             success:function(data){
               console.log(data)
               if(data.code==200){
                 alert("登录成功")
                 location.href="index.html";
               }else{
                 $(e.target).prev().html("登录失败")
               }
             }
          })


      }
    });
    $("[data-btn=register]").click(()=>{
      location.href="rg.html";
    });
  });